package expression.exceptions;

public enum Operator {
    ADD, MUL, DIV, SUB, RIGHT_SHIFT, LEFT_SHIFT, CLOSE_BRACKET, NEG, POW, LOG, NULL_OP
}