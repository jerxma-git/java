package expression.exceptions;

import expression.CommonExpression;
import expression.Logarithm;

public class CheckedLogarithm extends Logarithm {
    public CheckedLogarithm(CommonExpression expression) {
        super(expression);
    }

    @Override
    public int calculate(int val) {
        if (val < 1) {
            throw new UnsupportedArgumentException("log2 " + val);
        }
        return super.calculate(val);
    }
}