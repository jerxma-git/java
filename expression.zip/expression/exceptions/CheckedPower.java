package expression.exceptions;

import expression.CommonExpression;
import expression.Power;

public class CheckedPower extends Power {
    public CheckedPower(CommonExpression expression) {
        super(expression);
    }

    @Override
    public int calculate(int val) {
        if (val < 0) {
            throw new UnsupportedArgumentException("pow2 " + val); 
        }
        if (val > Integer.SIZE - 1) {
            throw new OverflowException("pow2 " + val);
        }
        // if (overflow 2^val)
        return super.calculate(val);
    }
}