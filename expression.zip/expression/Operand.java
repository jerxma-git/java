// package expression;

// public interface CommonExpression extends DoubleExpression, CommonExpression {
    
   

//     // @Override
//     // public boolean equals(Object obj) {
//     //     return obj != null && obj.getClass() == this.getClass();
//     // }

//     // protected abstract boolean isCommutative();

//     // protected abstract int getPriority();

//     // @Override
//     // public String toMiniString() {
//     //     return toString();
//     // }

//     // @Override
//     // public abstract int evaluate(int val);

//     // public abstract int evaluate(int x, int y, int z);
// }