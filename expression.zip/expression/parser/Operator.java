package expression.parser;

public enum Operator {
    ADD, MUL, DIV, SUB, RIGHT_SHIFT, LEFT_SHIFT, CLOSE_BRACKET
}